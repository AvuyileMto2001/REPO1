using System;
using System.Windows.Forms;

namespace CalculatorApp;

public partial class Form1 : Form
{
    private TextBox txtDisplay;
    private Button[] numberButtons;
    private Button btnAdd, btnSubtract, btnMultiply, btnDivide, btnEquals, btnClear;
    private double firstNumber;
    private string operation;
    private bool isOperationPerformed;

    public Form1()
    {
        InitializeComponent();
        InitializeCalculator();
    }

    private void InitializeCalculator()
    {
        this.Text = "Calculator";
        this.Size = new System.Drawing.Size(300, 400);

        txtDisplay = new TextBox();
        txtDisplay.Location = new System.Drawing.Point(10, 10);
        txtDisplay.Size = new System.Drawing.Size(260, 40);
        txtDisplay.Font = new System.Drawing.Font("Arial", 16);
        txtDisplay.TextAlign = HorizontalAlignment.Right;
        txtDisplay.ReadOnly = true;
        txtDisplay.Text = "0";
        this.Controls.Add(txtDisplay);

        // Create number buttons
        numberButtons = new Button[10];
        for (int i = 0; i < 10; i++)
        {
            numberButtons[i] = new Button();
            numberButtons[i].Text = i.ToString();
            numberButtons[i].Size = new System.Drawing.Size(50, 50);
            numberButtons[i].Click += NumberButton_Click;
        }

        // Position number buttons
        numberButtons[1].Location = new System.Drawing.Point(10, 60);
        numberButtons[2].Location = new System.Drawing.Point(70, 60);
        numberButtons[3].Location = new System.Drawing.Point(130, 60);
        numberButtons[4].Location = new System.Drawing.Point(10, 120);
        numberButtons[5].Location = new System.Drawing.Point(70, 120);
        numberButtons[6].Location = new System.Drawing.Point(130, 120);
        numberButtons[7].Location = new System.Drawing.Point(10, 180);
        numberButtons[8].Location = new System.Drawing.Point(70, 180);
        numberButtons[9].Location = new System.Drawing.Point(130, 180);
        numberButtons[0].Location = new System.Drawing.Point(10, 240);
        numberButtons[0].Size = new System.Drawing.Size(110, 50);

        for (int i = 0; i < 10; i++)
        {
            this.Controls.Add(numberButtons[i]);
        }

        // Operator buttons
        btnAdd = new Button();
        btnAdd.Text = "+";
        btnAdd.Location = new System.Drawing.Point(190, 60);
        btnAdd.Size = new System.Drawing.Size(50, 50);
        btnAdd.Click += OperatorButton_Click;
        this.Controls.Add(btnAdd);

        btnSubtract = new Button();
        btnSubtract.Text = "-";
        btnSubtract.Location = new System.Drawing.Point(190, 120);
        btnSubtract.Size = new System.Drawing.Size(50, 50);
        btnSubtract.Click += OperatorButton_Click;
        this.Controls.Add(btnSubtract);

        btnMultiply = new Button();
        btnMultiply.Text = "*";
        btnMultiply.Location = new System.Drawing.Point(190, 180);
        btnMultiply.Size = new System.Drawing.Size(50, 50);
        btnMultiply.Click += OperatorButton_Click;
        this.Controls.Add(btnMultiply);

        btnDivide = new Button();
        btnDivide.Text = "/";
        btnDivide.Location = new System.Drawing.Point(190, 240);
        btnDivide.Size = new System.Drawing.Size(50, 50);
        btnDivide.Click += OperatorButton_Click;
        this.Controls.Add(btnDivide);

        btnEquals = new Button();
        btnEquals.Text = "=";
        btnEquals.Location = new System.Drawing.Point(130, 240);
        btnEquals.Size = new System.Drawing.Size(50, 50);
        btnEquals.Click += EqualsButton_Click;
        this.Controls.Add(btnEquals);

        btnClear = new Button();
        btnClear.Text = "C";
        btnClear.Location = new System.Drawing.Point(250, 60);
        btnClear.Size = new System.Drawing.Size(50, 50);
        btnClear.Click += ClearButton_Click;
        this.Controls.Add(btnClear);
    }

    private void NumberButton_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        if (txtDisplay.Text == "0" || isOperationPerformed)
        {
            txtDisplay.Text = button.Text;
        }
        else
        {
            txtDisplay.Text += button.Text;
        }
        isOperationPerformed = false;
    }

    private void OperatorButton_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        firstNumber = double.Parse(txtDisplay.Text);
        operation = button.Text;
        isOperationPerformed = true;
    }

    private void EqualsButton_Click(object sender, EventArgs e)
    {
        double secondNumber = double.Parse(txtDisplay.Text);
        double result = 0;
        switch (operation)
        {
            case "+":
                result = firstNumber + secondNumber;
                break;
            case "-":
                result = firstNumber - secondNumber;
                break;
            case "*":
                result = firstNumber * secondNumber;
                break;
            case "/":
                if (secondNumber != 0)
                    result = firstNumber / secondNumber;
                else
                    MessageBox.Show("Cannot divide by zero");
                break;
        }
        txtDisplay.Text = result.ToString();
        isOperationPerformed = true;
    }

    private void ClearButton_Click(object sender, EventArgs e)
    {
        txtDisplay.Text = "0";
        firstNumber = 0;
        operation = "";
        isOperationPerformed = false;
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }
}
